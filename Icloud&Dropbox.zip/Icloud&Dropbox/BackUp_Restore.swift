//
//  BackUp_Restore.swift
//  TimeTick Analyzer
//
//  Created by NLS17-MAC on 2/23/18.
//  Copyright © 2018 Bhadresh Kathiriya. All rights reserved.
//

import UIKit
import SwiftyDropbox
import SSZipArchive

class BackUp_Restore: NSObject
{
    var zipPath: String?
    var objAppdelegate = AppDelegate()
    var recordCount = Int()
    
    func RestoreDropBoxData()
    {
        objAppdelegate = UIApplication.shared.delegate as! AppDelegate
        
        objAppdelegate.startActivityIndicator()
        
        let client = DropboxClientsManager.authorizedClient
        
        client?.files.listFolder(path: "").response(queue: DispatchQueue(label: "MyCustomSerialQueue"))
        { response, error in
            if let result = response
            {
                print(result.entries)
                
                for filename in result.entries
                {
                    print(filename.pathLower!)
                    
                    if filename.pathLower! == "/timetick.zip"
                    {
                        self.recordCount = self.recordCount + 1
                        
                        ModelManager.getInstance().closeDB()
                        
                        let fileManager = FileManager.default
                        let directoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
                        let destURL = directoryURL.appendingPathComponent("TimeTick.zip")
                        let destination: (URL, HTTPURLResponse) -> URL = { temporaryURL, response in
                            return destURL
                        }
                        let destination1: (URL, HTTPURLResponse) -> URL = { temporaryURL, response in
                            return directoryURL
                        }
                        client?.files.download(path: "/TimeTick.zip", overwrite: true, destination: destination)
                            .response { response, error in
                                if let response = response
                                {
                                    print(response)
                                    
                                    self.makeUnZipFileWithCompletion(sourcepath: destURL.path, destignation: directoryURL.path + "/TimeTick1", completionHandler: { (success) in
                                      
                                        if success == true
                                        {
                                            //                                        // Delete Current Folder after unzip Success
                                            do{ try FileManager.default.removeItem(atPath: directoryURL.path + "/TimeTick")}
                                            catch{}
                                            
                                            do{ try FileManager.default.moveItem(atPath: directoryURL.path + "/TimeTick1", toPath: directoryURL.path + "/TimeTick")}
                                            catch{}
                                            
                                            print("success unzip")
                                            // Delete Downloaded Folder
                                            do{ try FileManager.default.removeItem(atPath: destURL.path)}
                                            catch{}
                                            
                                            ModelManager.getInstance().openDB()
                                            
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                                self.objAppdelegate.stopActivityIndicator()
                                            }
                                            
                                            alert(title: str_DropBox, msg: str_restore_done)
                                        }
                                        else
                                        {
                                            print("error unzip")
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                                self.objAppdelegate.stopActivityIndicator()
                                            }
                                        }
                                    })
                                    
//                                    // Unzip Folder which is downloded from DropBox
//                                    let success: Bool = SSZipArchive.unzipFile(atPath: destURL.path,
//                                                                               toDestination: directoryURL.path + "/TimeTick1",
//                                                                               preserveAttributes: true,
//                                                                               overwrite: false,
//                                                                               nestedZipLevel: 1,
//                                                                               password: nil,
//                                                                               error: nil,
//                                                                               delegate: nil,
//                                                                               progressHandler: nil,
//                                                                               completionHandler: nil)
                                } else if let error = error
                                {
                                    print(error)
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                        self.objAppdelegate.stopActivityIndicator()
                                    }
                                }
                            }
                            .progress { progressData in
                                print(progressData)
                        }
                    }
                    else
                    {
                        
                        self.recordCount = self.recordCount + 1
                        
                        if self.recordCount == result.entries.count
                        {
                            print("file not Found")
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                self.objAppdelegate.stopActivityIndicator()
                            }
                        }
                        
                    }
                }
            }
        }
    }
    
    func BackupDropBoxData()
    {
        objAppdelegate = UIApplication.shared.delegate as! AppDelegate
        
        objAppdelegate.startActivityIndicator()
        let client = DropboxClientsManager.authorizedClient
        
        let fileManager = FileManager.default
        let directoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let destURL = directoryURL.appendingPathComponent("TimeTick").path
        
        zipPath = tempZipPath()
        
        // Convert to zip for upload to Dropbox
        let success = SSZipArchive.createZipFile(atPath: zipPath!,
                                                 withContentsOfDirectory: destURL,
                                                 keepParentDirectory: false,
                                                 compressionLevel: -1,
                                                 password: nil,
                                                 aes: true,
                                                 progressHandler: nil)
        
        if success == true
        {
            print("Zip Success")
            
            _ = "TimeTick.zip".data(using: String.Encoding.utf8, allowLossyConversion: false)!
            
            let data_file : Data = FileManager.default.contents(atPath: zipPath!)!
            
            // Delete first from Dropbox
            
            client?.files.deleteV2(path: "/TimeTick.zip").response(completionHandler: { (response, error) in
                if let metadata = response
                {
                    print(metadata.description)
                    print("delete file from dropBox")
                    
                    // Upload To dropBox
                    _ = client?.files.upload(path: "/TimeTick.zip", input: data_file)
                        .response { response, error in
                            if let response = response
                            {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    self.objAppdelegate.stopActivityIndicator()
                                }
                                print(response)
                                do{ try FileManager.default.removeItem(atPath: self.zipPath!)}
                                catch{}
                                
                                alert(title: str_DropBox, msg: str_backup_done)
                                
                            }
                            else if let error = error
                            {
                                print(error)
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    self.objAppdelegate.stopActivityIndicator()
                                }
                            }
                        }
                        .progress { progressData in
                            print(progressData)
                    }
                    
                }
                else {
                    // Error to Delete File
                    print("Error to Delete Folder :\(String(describing: error))")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        self.objAppdelegate.stopActivityIndicator()
                    }
                }
            })
        }
        else
        {
            print("zip error")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.objAppdelegate.stopActivityIndicator()
            }
        }
    }
    
    func tempZipPath() -> String
    {
        let fileManager = FileManager.default
        var path = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0].path
        var str = String()
        str = "TimeTick"
        path += "/\(str).zip"
        return path
    }
    
    func makeZipFileWithCompletion(completionHandler : (Bool?) -> Swift.Void)
    {

        let fileManager = FileManager.default
        let directoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let destURL = directoryURL.appendingPathComponent("TimeTick").path
        
        zipPath = tempZipPath()
        
        // Convert to zip for upload to Dropbox
        let success = SSZipArchive.createZipFile(atPath: zipPath!,
                                                 withContentsOfDirectory: destURL,
                                                 keepParentDirectory: false,
                                                 compressionLevel: -1,
                                                 password: nil,
                                                 aes: true,
                                                 progressHandler: nil)
        
        completionHandler(success)
    }
    
    func makeUnZipFileWithCompletion(sourcepath : String?, destignation : String? ,completionHandler : (Bool?) -> Swift.Void)
    {
        // Unzip Folder which is downloded from DropBox
        let success: Bool = SSZipArchive.unzipFile(atPath: sourcepath!,
                                                   toDestination: destignation!,
                                                   preserveAttributes: true,
                                                   overwrite: false,
                                                   nestedZipLevel: 1,
                                                   password: nil,
                                                   error: nil,
                                                   delegate: nil,
                                                   progressHandler: nil,
                                                   completionHandler: nil)
        completionHandler(success)
    }
    
    
    
    // iCloud Data Sync
    
    
    func saveFileToiClod(filedata : Data?,completionHandler : @escaping (Bool?) -> Swift.Void)
    {
        iCloud.shared().saveAndCloseDocument(withName: "TimeTick.zip", withContent: filedata!, completion: { (document : UIDocument?, docuumentData : Data?, error : Error?) in
            if error == nil
            {
                print("documentData : \(String(describing: docuumentData))")
                print("document : \(String(describing: document))")
                completionHandler(true)
            }
            else
            {
                print("Error : \(String(describing: error?.localizedDescription))")
                completionHandler(false)
            }
        })
    }
    
    func BackupiClouddata()
    {
        if (iCloud.shared().checkAvailability())
        {
            ModelManager.getInstance().closeDB()
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.objAppdelegate.startActivityIndicator()
            }
            
            self.makeZipFileWithCompletion { (status) in
                
                if status == true
                {
                    print("Zip Success")
                    
                    let fileManager = FileManager.default
                    let directoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
                    let destURL = directoryURL.appendingPathComponent("TimeTick.zip")
                    let data_file : Data = FileManager.default.contents(atPath: destURL.path)!
                    
                    let isExistFile : Bool = iCloud.shared().doesFileExist(inCloud: "TimeTick.zip")
                    
                    if isExistFile == true
                    {
                        print("File Exist")
                        
                        iCloud.shared().deleteDocument(withName: "TimeTick.zip", completion: { (error : Error?) in
                            
                            if error == nil
                            {
                                print("delete file")
                                
                                self.saveFileToiClod(filedata: data_file, completionHandler: { (status) in
                                    
                                    if status == true
                                    {
//                                        // Delete Zip file after save file
                                        do{ try FileManager.default.removeItem(atPath: destURL.path)}
                                        catch{}
                                        
                                        print("save file Success")
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                            self.objAppdelegate.stopActivityIndicator()
                                        }
                                        ModelManager.getInstance().openDB()
                                        
                                        alert(title: str_iCloud, msg: str_backup_done)
                                    }
                                    else
                                    {
                                        print("failed to save file")
                                        
                                        // Delete Zip file when Failed to save file in iCloud
                                        do{ try FileManager.default.removeItem(atPath: destURL.path)}
                                        catch{}
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                            self.objAppdelegate.stopActivityIndicator()
                                        }
                                        ModelManager.getInstance().openDB()
                                    }
                                })
                            }
                            else
                            {
                                // Delete Zip file when Failed to Delete file
                                do{ try FileManager.default.removeItem(atPath: destURL.path)}
                                catch{}
                                print("Error with Delete file :\(String(describing: error?.localizedDescription))")
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    self.objAppdelegate.stopActivityIndicator()
                                }
                                ModelManager.getInstance().openDB()
                            }
                        })
                    }
                    else
                    {
                        print("File not Exist need to save")
                        
                        self.saveFileToiClod(filedata: data_file, completionHandler: { (status) in
                            
                            if status == true
                            {
//                                // Delete Zip file when save file to iCloud
                                do{ try FileManager.default.removeItem(atPath: destURL.path)}
                                catch{}
                                print("save file Success")
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    self.objAppdelegate.stopActivityIndicator()
                                }
                                ModelManager.getInstance().openDB()
                                alert(title: str_iCloud, msg: str_backup_done)
                            }
                            else
                            {
                                // Delete zip file when Failed to save file in iCloud
                                do{ try FileManager.default.removeItem(atPath: destURL.path)}
                                catch{}
                                print("failed to save file")
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    self.objAppdelegate.stopActivityIndicator()
                                }
                                ModelManager.getInstance().openDB()
                            }
                        })
                    }
                }
                else
                {
                    print("Zip Fail")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        self.objAppdelegate.stopActivityIndicator()
                    }
                    ModelManager.getInstance().openDB()
                }
            }
        }
        else
        {
            print("icloud not available.")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.objAppdelegate.stopActivityIndicator()
            }
            ModelManager.getInstance().openDB()
        }
    }
    
    
    func RestoreiClouddata()
    {
        if (iCloud.shared().checkAvailability())
        {
            ModelManager.getInstance().closeDB()
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.objAppdelegate.startActivityIndicator()
            }
            
            let isExistFile : Bool = iCloud.shared().doesFileExist(inCloud: "TimeTick.zip")
            
            if isExistFile == true
            {
                print("File Exist in iCloud")
                
                iCloud.shared().retrieveCloudDocument(withName: "TimeTick.zip", completion: { (document : UIDocument?, docuumentData : Data?, error : Error?) in
                    
                    if error == nil
                    {
                        print("Retrive success")
                        print("docuumentData :\(docuumentData!)")
                        
                        let fileData : Data = docuumentData!
                        print("fileData : \(fileData)")
                        
                        let fileManager = FileManager.default
                        let directoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
                        let destURL = directoryURL.appendingPathComponent("TimeTick.zip")
                        do{ try fileData.write(to: destURL)} catch{}
                        
                        self.makeUnZipFileWithCompletion(sourcepath: destURL.path, destignation: directoryURL.path + "/TimeTick1", completionHandler: { (status) in
                            
                            if status == true
                            {
                                print("Unzip file success")
                                
                                // Delete Current Folder after unzip Success
                                do{ try FileManager.default.removeItem(atPath: directoryURL.path + "/TimeTick")}
                                catch{}
                                
                                // Move new folder data to another folder
                                do{ try FileManager.default.moveItem(atPath: directoryURL.path + "/TimeTick1", toPath: directoryURL.path + "/TimeTick")}
                                catch{}
                                
                                // Delete Downloaded zip Folder
                                do{ try FileManager.default.removeItem(atPath: destURL.path)}
                                catch{}
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    self.objAppdelegate.stopActivityIndicator()
                                }
                                ModelManager.getInstance().openDB()
                                
                                alert(title: str_iCloud, msg: str_restore_done)
                            }
                            else
                            {
                                print("Unzip failed")
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    self.objAppdelegate.stopActivityIndicator()
                                }
                                ModelManager.getInstance().openDB()
                            }
                            
                        })
                    }
                    else
                    {
                        print("failed to retrive file from iCloud")
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            self.objAppdelegate.stopActivityIndicator()
                        }
                        ModelManager.getInstance().openDB()
                    }
                })
            }
            else
            {
                print("file not Exist in iCloud")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.objAppdelegate.stopActivityIndicator()
                }
                ModelManager.getInstance().openDB()
            }
        }
        else
        {
            print("iCloud Svailablity not Available")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.objAppdelegate.stopActivityIndicator()
            }
            ModelManager.getInstance().openDB()
        }
    }
}
