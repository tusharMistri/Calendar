//
//  Backup_RestoreViewController.swift
//  TimeTick Analyzer
//
//  Created by NLS17-MAC on 2/22/18.
//  Copyright © 2018 Bhadresh Kathiriya. All rights reserved.
//

import UIKit

// DropBox
import SwiftyDropbox
import SSZipArchive

class Backup_RestoreViewController: UIViewController {

    var objAppdelegate = AppDelegate()
    var singleToneBackup = BackUp_Restore()
    @IBOutlet var constTopHeight: NSLayoutConstraint!
    
    //MARK: - View Lifecycle
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        constTopHeight.constant = kHeaderHeight
        objAppdelegate = UIApplication.shared.delegate as! AppDelegate
    }
    
    //MARK: - Control Action Methods
    
    // iCloud
    @IBAction func controlClickiCloudBackup(_ sender: UIControl)
    {
        singleToneBackup.BackupiClouddata()
    }
        
    @IBAction func controlClickiCloudRestore(_ sender: UIControl)
    {
        singleToneBackup.RestoreiClouddata()
    }
    
    //DropBox
    @IBAction func controlClickDropBoxBackup(_ sender: UIControl)
    {
        if DropboxClientsManager.authorizedClient == nil
        {
            objAppdelegate.isDownloading_DropBox = true
            DropboxClientsManager.authorizeFromController(UIApplication.shared,
                                                          controller: self,
                                                          openURL: { (url: URL) -> Void in
                                                            UIApplication.shared.openURL(url)
            })
        }
        else
        {
            objAppdelegate.isDownloading_DropBox = true
            self.singleToneBackup.BackupDropBoxData()
        }
    }
    
    @IBAction func controlClickDropBoxRestore(_ sender: UIControl)
    {
        if DropboxClientsManager.authorizedClient == nil
        {
            objAppdelegate.isDownloading_DropBox = false
            DropboxClientsManager.authorizeFromController(UIApplication.shared,
                                                          controller: self,
                                                          openURL: { (url: URL) -> Void in
                                                            UIApplication.shared.openURL(url)
            })
        }
        else
        {
            objAppdelegate.isDownloading_DropBox = false
            self.singleToneBackup.RestoreDropBoxData()
        }
    }
    
    // Back
    @IBAction func controlClickBack(_ sender: UIControl)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: - Extra Methods
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

}
