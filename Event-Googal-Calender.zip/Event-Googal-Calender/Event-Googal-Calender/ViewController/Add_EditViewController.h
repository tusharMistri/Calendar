//
//  Add_EditViewController.h
//  Event-Googal-Calender
//
//  Created by NLS17-MAC on 1/18/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@protocol addEditCalendarEventDelegate <NSObject>

-(void)addEventToGooelCalenderWithName:(NSString *)strName withStartDate:(NSString *)strStartDate withEndDate:(NSString *)strEndDate;
-(void)editEventToGooelCalenderWithName:(NSString *)strName withStartDate:(NSString *)strStartDate withEndDate:(NSString *)strEndDate calenderId:(NSString *)strCalenderId eventId:(NSString *)strEventId;

@end

@interface Add_EditViewController : UIViewController

@property (strong,nonatomic) NSString *stredit_Add;
@property (strong,nonatomic) NSIndexPath *objIndxpath;
@property (strong,nonatomic) NSDate *dateFromPicker;
@property (strong,nonatomic) NSString *strStartDate_endaDate;
@property (strong,nonatomic) NSString *strStartDate;
@property (strong,nonatomic) NSString *strEndDate;

@property (strong, nonatomic) IBOutlet UILabel *labelTile;
@property (strong, nonatomic) IBOutlet UIView *viewPopupPicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *objDatePicker;
@property (strong, nonatomic) IBOutlet UIButton *buttonAdd_Edit;
@property (strong, nonatomic) IBOutlet UITextField *textfieldEventName;
@property (strong, nonatomic) IBOutlet UIButton *buttonStartDate;
@property (strong, nonatomic) IBOutlet UIButton *buttonEndDate;

@property (strong,nonatomic) id<addEditCalendarEventDelegate> EventDelegate;

- (IBAction)buttonClickPickerCancel:(UIButton *)sender;
- (IBAction)buttonClickCancel:(UIButton *)sender;
- (IBAction)buttonClickStartDate:(UIButton *)sender;
- (IBAction)buttonClickEndDate:(UIButton *)sender;
- (IBAction)buttonClickPickerDone:(UIButton *)sender;



@end
