//
//  ViewController.h
//  Event-Googal-Calender
//
//  Created by NLS17-MAC on 1/13/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <Google/SignIn.h>
#import <GTLRCalendar.h>

#import <GTMOAuth2ViewControllerTouch.h>
#import <GTMOAuth2Authentication.h>

#import "AppDelegate.h"
#import "customCell.h"

#import "Add_EditViewController.h"

#import <UserNotifications/UserNotifications.h>

@interface ViewController : UIViewController <UITableViewDelegate , UITableViewDataSource>
{
    BOOL isInsert;
    
    IBOutlet UITableView *objtableview;
    
    AppDelegate *objappdelegate;
}
@property (strong, nonatomic) IBOutlet UIButton *buttoSync;

@property (strong, nonatomic) IBOutlet UIImageView *iamge_sync;

@property (nonatomic, strong) IBOutlet GIDSignInButton *signInButton;
@property (nonatomic, strong) UITextView *output;
@property (nonatomic, strong) GTLRCalendarService *service;


- (IBAction)ClickControl_SyncData:(UIControl *)sender;

@end

