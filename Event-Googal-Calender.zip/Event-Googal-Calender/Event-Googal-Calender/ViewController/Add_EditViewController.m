//
//  Add_EditViewController.m
//  Event-Googal-Calender
//
//  Created by NLS17-MAC on 1/18/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import "Add_EditViewController.h"

@interface Add_EditViewController ()
{
    AppDelegate *objAppdelegate;
}
@end

@implementation Add_EditViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    objAppdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [self setupLayout];
}

#pragma mark - Void Methods

-(void)setupLayout
{
    self.viewPopupPicker.alpha = 0.0;
    
    self.labelTile.text = self.stredit_Add;
    [self.buttonAdd_Edit setTitle:[self.stredit_Add isEqualToString:@"Add Event"] ? @"Add" : @"Edit" forState:UIControlStateNormal];
    
    self.objDatePicker.minimumDate = [NSDate date];
    
    self.textfieldEventName.text = [self.stredit_Add isEqualToString:@"Add Event"] ? @"" : [[objAppdelegate.arrayEvents objectAtIndex:self.objIndxpath.row] valueForKey:kName];
    
    [self.stredit_Add isEqualToString:@"Add Event"] ? NSLog(@"no date") : NSLog(@"Start Date : %@",[[objAppdelegate.arrayEvents objectAtIndex:self.objIndxpath.row] valueForKey:kStartDate]);
    [self.stredit_Add isEqualToString:@"Add Event"] ? NSLog(@"no date") : NSLog(@"End Date : %@",[[objAppdelegate.arrayEvents objectAtIndex:self.objIndxpath.row] valueForKey:kEndDate]);

    [self.stredit_Add isEqualToString:@"Add Event"] ? [self.buttonStartDate setTitle:@"Start Date" forState:UIControlStateNormal] : [self.buttonStartDate setTitle:[self convertStringToDateFormatWithString:[[objAppdelegate.arrayEvents objectAtIndex:self.objIndxpath.row] valueForKey:kStartDate]] forState:UIControlStateNormal];
   
    [self.stredit_Add isEqualToString:@"Add Event"] ? [self.buttonEndDate setTitle:@"End Date" forState:UIControlStateNormal] : [self.buttonEndDate setTitle:[self convertStringToDateFormatWithString:[[objAppdelegate.arrayEvents objectAtIndex:self.objIndxpath.row] valueForKey:kEndDate]] forState:UIControlStateNormal];
    
    NSLog(@"Button Start Date : %@",self.buttonStartDate.titleLabel.text);
    NSLog(@"Button End Date : %@",self.buttonEndDate.titleLabel.text);
    
}

-(BOOL)compairetwoDate:(NSDate *)startDate endate:(NSDate *)endDate
{
    NSComparisonResult result;
    //has three possible values: NSOrderedSame,NSOrderedDescending, NSOrderedAscending
    
    result = [startDate compare:endDate]; // comparing two dates
    
    if(result==NSOrderedAscending){
        NSLog(@"today is less");
    return false;
    }
    else if(result==NSOrderedDescending)
    {
        NSLog(@"newDate is less");
        return true;
    }
    else
    {
        NSLog(@"Both dates are same");
        return false;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Animations

-(void) fadeIn:(UIView*)viewToFadeIn withDuration:(NSTimeInterval)duration andWait:(NSTimeInterval)wait
{
    
    [UIView beginAnimations: @"Fade In" context:nil];
    
    // wait for time before begin
    [UIView setAnimationDelay:wait];
    
    // druation of animation
    [UIView setAnimationDuration:duration];
    viewToFadeIn.alpha = 50.0;
    [UIView commitAnimations];
    
}

-(void)fadeOut:(UIView*)viewToDissolve withDuration:(NSTimeInterval)duration   andWait:(NSTimeInterval)wait
{    
    [UIView beginAnimations: @"Fade Out" context:nil];

    // wait for time before begin
    [UIView setAnimationDelay:wait];
    
    // druation of animation
    [UIView setAnimationDuration:duration];
    viewToDissolve.alpha = 0.0;
    [UIView commitAnimations];
}

-(NSString *)convertDatetoFormat:(NSString *)format withDate:(NSDate *)objdate
{
    NSDateFormatter *objDateFormatter = [[NSDateFormatter alloc] init];
//    [objDateFormatter setLocale:[NSLocale currentLocale]];
    [objDateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [objDateFormatter setDateFormat:format];
    NSString *strDate = [objDateFormatter stringFromDate:objdate];
    
    return strDate;
}

//-(NSString *)convertDatetoFormat:(NSDate *)objdate
//{
//    NSDateFormatter *objDateFormatter = [[NSDateFormatter alloc] init];
////    [objDateFormatter setLocale:[NSLocale currentLocale]];
//    [objDateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
//    [objDateFormatter setDateFormat:@"yyyy-MM-dd"];
//    NSString *strDate = [objDateFormatter stringFromDate:objdate];
//    [objDateFormatter setDateFormat:@"HH:mm:ss"];
//
//    return [NSString stringWithFormat:@"%@T%@z",strDate, [objDateFormatter stringFromDate:objdate]];
//}


//-(NSString *)convertDatewithString:(NSString *)strDate
//{
//    NSString *strFormat = [NSString stringWithFormat:@"%@z",@"yyyy-MM-dd'T'HH:mm:ss"];
//    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
//    [dateFormat setDateFormat:strFormat];
//    NSDate *date_ = [dateFormat dateFromString:strDate];
//
//    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//    NSString *str_start = [dateFormat stringFromDate:date_];
//
//    return str_start;
//}

#pragma mark - Button Action Methods

- (IBAction)datepicker_valuechange:(UIDatePicker *)sender
{
    NSLog(@"date : %@",sender.date);
    self.dateFromPicker = sender.date;
}

- (IBAction)buttonClickPickerCancel:(UIButton *)sender
{
    [self fadeOut:self.viewPopupPicker withDuration:0.5f andWait:0.f];
}

- (IBAction)buttonClickCancel:(UIButton *)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)buttonClickAdd_Edit:(UIButton *)sender
{
    if (self.textfieldEventName.text == nil || [self.textfieldEventName.text isEqualToString:@""])
    {
        [self showAlertWithMessage:@"Enter event name"];
    }
    else if ([self.buttonStartDate.titleLabel.text isEqualToString:@"Start Date"])
    {
        [self showAlertWithMessage:@"select start date"];
    }
    else if ([self.buttonEndDate.titleLabel.text isEqualToString:@"End Date"])
    {
        [self showAlertWithMessage:@"select end date"];
    }
    else
    {
        [self.stredit_Add isEqualToString:@"Add Event"] ? [self.EventDelegate addEventToGooelCalenderWithName:self.textfieldEventName.text withStartDate:self.strStartDate withEndDate:self.strEndDate] : [self.EventDelegate editEventToGooelCalenderWithName:self.textfieldEventName.text withStartDate:self.strStartDate withEndDate:self.strEndDate calenderId:@"primary" eventId:[[objAppdelegate.arrayEvents objectAtIndex:self.objIndxpath.row]valueForKey:kidentifier]];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)buttonClickStartDate:(UIButton *)sender
{
    self.objDatePicker.minimumDate = [NSDate date];
    
    [self.view endEditing:YES];
    self.strStartDate_endaDate = @"Start Date";
    
    [self.stredit_Add isEqualToString:@"Add Event"] ? : [self setPickerDefultDate:self.buttonStartDate.titleLabel.text] ;
    
    [self fadeIn:self.viewPopupPicker withDuration:0.5f andWait:0.f];
}

- (IBAction)buttonClickEndDate:(UIButton *)sender
{
    [self.view endEditing:YES];
    self.strStartDate_endaDate = @"End Date";
    
    [self.stredit_Add isEqualToString:@"Add Event"] ? : [self setPickerDefultDate:self.buttonEndDate.titleLabel.text] ;
    
    [self fadeIn:self.viewPopupPicker withDuration:0.5f andWait:0.f];
    
}

- (IBAction)buttonClickPickerDone:(UIButton *)sender
{
    [self fadeOut:self.viewPopupPicker withDuration:0.5f andWait:0.f];
    
    NSString *strDate = [NSString stringWithFormat:@"%@z",[self convertDatetoFormat:@"yyyy-MM-dd'T'HH:mm:ss" withDate:self.dateFromPicker]];
    
//    NSString *strDate = [self convertDatetoFormat:self.dateFromPicker];
    
    NSLog(@"strDate : %@",strDate);
    
    if ([self.strStartDate_endaDate isEqualToString:@"Start Date"])
    {
        // set date for start Date
        self.strStartDate = strDate;
        [self.buttonStartDate setTitle:[self convertStringToDateFormatWithString:strDate] forState:UIControlStateNormal];
        
        [self.stredit_Add isEqualToString:@"Add Event"] ? [self.buttonEndDate setTitle:@"End Date" forState:UIControlStateNormal] : [self.buttonEndDate setTitle:@"End Date" forState:UIControlStateNormal];
    }
    else
    {
        //set date for end date
        self.strEndDate = strDate;
        [self.buttonEndDate setTitle:[self convertStringToDateFormatWithString:strDate] forState:UIControlStateNormal];
    }
    
    self.objDatePicker.minimumDate = self.dateFromPicker;

}

#pragma mark - DateFormatter Methods

-(NSString *)convertStringToDateFormatWithString:(NSString *)stringDate
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssz"];
    
    NSDate *date_ = [dateFormat dateFromString:stringDate];

    [dateFormat setDateFormat:@"yyyy-MM-dd hh:mm a"];
    NSString *date_string = [dateFormat stringFromDate:date_];
    
    return date_string;
}

-(void)setPickerDefultDate:(NSString *)stringDate
{
    NSDateFormatter *form = [[NSDateFormatter alloc]init];
    [form setDateFormat:@"yyyy-MM-dd hh:mm a"];
    NSDate *date_ = [form dateFromString:stringDate];
    NSLog(@"date_ : %@",date_);

    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *currentDate = date_;//[NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSDate *minDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];

    NSLog(@"minDate %@",minDate);
    
    self.objDatePicker.minimumDate = minDate;
    
}

#pragma mark - AlertView

-(void)showAlertWithMessage:(NSString *)strMessage
{
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Google-Calendar" message:strMessage preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil]];
        
    [self presentViewController:alert animated:YES completion:nil];
}

@end
