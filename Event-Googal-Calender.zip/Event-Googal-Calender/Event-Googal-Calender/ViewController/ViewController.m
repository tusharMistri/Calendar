//
//  ViewController.m
//  Event-Googal-Calender
//
//  Created by NLS17-MAC on 1/13/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import "ViewController.h"

#define kKeychainItemName @"test-calender-c1333"
#define kClientID @"527000458494-1uoura87rshs0g44s8oo8j6c9amfrmop.apps.googleusercontent.com"
#define kClientSecret @"AIzaSyDqFX7Ab1dyShzklAzMJeTBSzREy26Lz4k"

#define kCardId @"primary"



@interface ViewController () <GIDSignInDelegate, GIDSignInUIDelegate , addEditCalendarEventDelegate>

@end

@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    objappdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    if ([[NSUserDefaults standardUserDefaults]boolForKey:kSyncGoogle] == YES)
    {
        self.buttoSync.hidden = false;
        [self setSyncDataSetup];
    }
    else
    {
        self.buttoSync.hidden = true;
    }
}

-(void)setSyncDataSetup
{
    // Initialize the service object.

    self.service = [[GTLRCalendarService alloc] init];
    
    // Configure Google Sign-in.
    GIDSignIn* signIn = [GIDSignIn sharedInstance];
    signIn.delegate = self;
    signIn.uiDelegate = self;
    //    signIn.scopes = [NSArray arrayWithObjects:kGTLRAuthScopeCalendarReadonly, nil];
    signIn.scopes = [NSArray arrayWithObjects:kGTLRAuthScopeCalendar, nil];
    [signIn signInSilently];
    
    // Add the sign-in button.
    //    self.signInButton = [[GIDSignInButton alloc] initWithFrame:CGRectMake(self.view.frame.size.width / 2 - (125), self.view.frame.size.height /2 - (25) , 250, 50)];
    [[[GIDSignInButton alloc] init] sendActionsForControlEvents:UIControlEventTouchUpInside];
    //    [self.signInButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    //    [self.view addSubview:self.signInButton];

}

- (void)signIn:(GIDSignIn *)signIn
didSignInForUser:(GIDGoogleUser *)user
     withError:(NSError *)error
{
    if (error != nil)
    {
        [self showAlert:@"Authentication Error" message:error.localizedDescription];
        self.service.authorizer = nil;
    } else {
        self.signInButton.hidden = true;
//        self.output.hidden = false;
        self.service.authorizer = user.authentication.fetcherAuthorizer;
       [self fetchEvents];
    }
}

- (void)fetchEvents
{
    GTLRCalendarQuery_EventsList *query =
    [GTLRCalendarQuery_EventsList queryWithCalendarId:@"primary"];
//    query.maxResults = 10;
//    query.timeMin = [GTLRDateTime dateTimeWithDate:[NSDate date]];
    query.singleEvents = YES;
    query.orderBy = kGTLRCalendarOrderByStartTime;
    
    [self.service executeQuery:query
                      delegate:self
             didFinishSelector:@selector(displayResultWithTicket:finishedWithObject:error:)];
}

- (void)displayResultWithTicket:(GTLRServiceTicket *)ticket
             finishedWithObject:(GTLRCalendar_Events *)events
                          error:(NSError *)error {
    if (error == nil)
    {
        NSMutableString *output = [[NSMutableString alloc] init];
            if (events.items.count > 0)
            {
                [output appendString:@"Upcoming events:\n"];
                for (GTLRCalendar_Event *event in events)
                {
                    NSLog(@"Json : %@",event.JSON);
                    
                    GTLRDateTime *start = event.start.dateTime ?: event.start.date;
                    NSString *startString =
                    [NSDateFormatter localizedStringFromDate:[start date]
                                                   dateStyle:NSDateFormatterShortStyle
                                                   timeStyle:NSDateFormatterShortStyle];
                    [output appendFormat:@"%@ - %@\n", startString, event.summary];
                    
                    if (objappdelegate.arrayEvents.count - [objappdelegate.array_Events count] != events.items.count)
                    {
                        NSDictionary *dicEvent = @{kName:event.summary , kStartDate:event.start.dateTime.stringValue ?: event.start.date.stringValue , kEndDate :event.end.dateTime.stringValue ?: event.end.date.stringValue , kidentifier : event.identifier , kLocation : @"google-calender"};
                        [objappdelegate.arrayEvents addObject:dicEvent];
                        
                        if ([[objappdelegate arrayEvents] count] == events.items.count) {
                            [self setNotificationWithTile];
                        }
                    }
                    
                    NSLog(@"Appdelagte array : %@",[objappdelegate arrayEvents]);
                    
                    NSLog(@"output : %@",output);
                }
            } else {
                [output appendString:@"No upcoming events found."];
                NSLog(@"output : %@",output);
            }
        
        for (int i=0; i<objappdelegate.array_Events.count; i++)
        {
            if (![objappdelegate.arrayEvents containsObject:[objappdelegate.array_Events objectAtIndex:i]])
            {
                [objappdelegate.arrayEvents addObject:[objappdelegate.array_Events objectAtIndex:i]];
            }
        }
    
        NSLog(@"Appdelagte array : %@",[objappdelegate arrayEvents]);

        [objtableview reloadData];
        return;
    } else {
        [self showAlert:@"Error" message:error.localizedDescription];
    }
}

// Helper for showing an alert
- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:title
                                        message:message
                                 preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok =
    [UIAlertAction actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * action)
     {
         [alert dismissViewControllerAnimated:YES completion:nil];
     }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)deleteEvent:(NSIndexPath *)indexpath
{
 
    if ([[[objappdelegate.arrayEvents objectAtIndex:indexpath.row] valueForKey:kLocation] isEqualToString:@"application"])
    {
        [objappdelegate.array_Events removeObject:[objappdelegate.arrayEvents objectAtIndex:indexpath.row]];
        [objappdelegate.arrayEvents removeObjectAtIndex:indexpath.row];
        [objtableview reloadData];
    }
    else
    {
        GTLRCalendarQuery_EventsDelete *delete = [GTLRCalendarQuery_EventsDelete queryWithCalendarId:@"primary" eventId:[[objappdelegate.arrayEvents objectAtIndex:indexpath.row]valueForKey:kidentifier]];
        
        [self.service executeQuery:delete completionHandler:^(GTLRServiceTicket * _Nonnull callbackTicket, id  _Nullable object, NSError * _Nullable callbackError) {
            
            if (!callbackError)
            {
                [objappdelegate.arrayEvents removeObjectAtIndex:indexpath.row];
                [self fetchEvents];
            }
            else
            {
                NSLog(@"callbackError : %@",callbackError.localizedDescription);
            }
            
        }];
    }
}


- (IBAction)buttonClickAddEvent:(UIButton *)sender
{
    Add_EditViewController *objADDEDITVC = [self.storyboard instantiateViewControllerWithIdentifier:@"Add_EditViewController"];
    objADDEDITVC.stredit_Add = @"Add Event";
    objADDEDITVC.EventDelegate = self;
    [self presentViewController:objADDEDITVC animated:YES completion:nil];

//    [self addEvent];
}

-(NSString *)convertDatetoFormat:(NSString *)format withDate:(NSDate *)objdate
{
    NSDateFormatter *objDateFormatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [objDateFormatter setTimeZone:timeZone];
    [objDateFormatter setDateFormat:format];
    NSString *strDate = [NSString stringWithFormat:@"%@z",[objDateFormatter stringFromDate:objdate]];
    
    return strDate;
}

-(NSDate *)convertStringToDate:(NSString *)format withDate:(NSString *)strDate
{
    NSDateFormatter *objDateFormatter = [[NSDateFormatter alloc] init];
    [objDateFormatter setDateFormat:[NSString stringWithFormat:@"%@z",format]];
//    NSTimeZone *timezone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+5:30"];
//    [objDateFormatter setTimeZone:timezone];
    NSDate *date = [objDateFormatter dateFromString:strDate];
    return date;
}

-(NSDateComponents *)dateWithOutTime:(NSDate *)datDate
{
    if (datDate == nil)
    {
        datDate = [NSDate date];
    }
    
    unsigned int      intFlags   = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay;
    NSCalendar       *calendar   = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian] ;
    NSDateComponents *components = [[NSDateComponents alloc] init] ;
    
    components = [calendar components:intFlags fromDate:datDate];
    
    return components;
    
}

- (IBAction)buttonClickSync:(UIButton *)sender
{
    [objappdelegate.arrayEvents removeAllObjects];
    
    [self fetchEvents];
}

#pragma mark - UITableview - Delegate

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

-(NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewRowAction *delteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDefault title:@"Delete" handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        NSLog(@"Delete Action");
        [self deleteEvent:indexPath];
    }];
    
    UITableViewRowAction *editAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDefault title:@"Edit" handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        NSLog(@"Edit Action");
//        [self updateEvent:indexPath];
        Add_EditViewController *objADDEDITVC = [self.storyboard instantiateViewControllerWithIdentifier:@"Add_EditViewController"];
        objADDEDITVC.stredit_Add = @"Edit Event";
        objADDEDITVC.objIndxpath = indexPath;
        objADDEDITVC.EventDelegate = self;
        [self presentViewController:objADDEDITVC animated:YES completion:nil];
    }];
    editAction.backgroundColor = [UIColor lightGrayColor];
    return @[delteAction,editAction];
}

#pragma mark - UITableview - DataSource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return objappdelegate.arrayEvents.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    customCell *cell = [tableView dequeueReusableCellWithIdentifier:@"customCell"];
    
    cell.labelName.text = [[objappdelegate.arrayEvents objectAtIndex:indexPath.row] valueForKey:kName];
    cell.labelStartTime.text = [self convertStringDateWithString:[[objappdelegate.arrayEvents objectAtIndex:indexPath.row] valueForKey:kStartDate]];
    cell.labelendTime.text = [self convertStringDateWithString:[[objappdelegate.arrayEvents objectAtIndex:indexPath.row] valueForKey:kEndDate]];
    return  cell;
    
}

#pragma mark - addEditCalendarEventDelegate

-(void)addEventToGooelCalenderWithName:(NSString *)strName withStartDate:(NSString *)strStartDate withEndDate:(NSString *)strEndDate
{
    if ([[NSUserDefaults standardUserDefaults]boolForKey:kSyncGoogle] == YES)
    {
            // Sync button On
        
        GTLRCalendar_Event *addevent = [[GTLRCalendar_Event alloc]init];
        addevent.summary = strName;
        
        GTLRCalendar_EventDateTime *date_time = [[GTLRCalendar_EventDateTime alloc]init];
        //    date_time.dateTime = [GTLRDateTime dateTimeWithRFC3339String:[self convertDatetoFormat:@"yyyy-MM-dd'T'HH:mm:ss" withDate:[NSDate date]]];
        date_time.dateTime = [GTLRDateTime dateTimeWithRFC3339String:strStartDate];
        
        addevent.start = date_time;
        
        GTLRCalendar_EventDateTime *date_time_end = [[GTLRCalendar_EventDateTime alloc]init];
        //    date_time_end.dateTime = [GTLRDateTime dateTimeWithRFC3339String:[self convertDatetoFormat:@"yyyy-MM-dd'T'HH:mm:ss" withDate:dat]];
        date_time_end.dateTime = [GTLRDateTime dateTimeWithRFC3339String:strEndDate];
        addevent.end = date_time_end;
        
        
        GTLRCalendarQuery_EventsInsert *insert = [GTLRCalendarQuery_EventsInsert queryWithObject:addevent calendarId:@"primary"];
        
        [self.service executeQuery:insert completionHandler:^(GTLRServiceTicket * _Nonnull callbackTicket, id  _Nullable object, NSError * _Nullable callbackError) {
            
            if (!callbackError)
            {
                [[objappdelegate arrayEvents] removeAllObjects];
                [self fetchEvents];
            }
            else
            {
                NSLog(@"callbackError : %@",callbackError.localizedDescription);
            }
            
        }];
    }
    else
    {
        // Sync button Off
        
        NSDictionary *dic = @{kName : strName ,kStartDate : strStartDate ,kEndDate : strEndDate , kLocation : @"application"};
        [objappdelegate.array_Events addObject:dic];
        
        NSLog(@"objappdelegate.array_Events : %@",objappdelegate.array_Events);
     
        NSLog(@"Events attay : %@",objappdelegate.arrayEvents);

        [objappdelegate.arrayEvents addObject:dic];
        
        NSLog(@"Events attay : %@",objappdelegate.arrayEvents);
        
        [objtableview reloadData];
    }
}

-(void)editEventToGooelCalenderWithName:(NSString *)strName withStartDate:(NSString *)strStartDate withEndDate:(NSString *)strEndDate calenderId:(NSString *)strCalenderId eventId:(NSString *)strEventId
{
    if ([[NSUserDefaults standardUserDefaults]boolForKey:kSyncGoogle] == YES)
    {
        // Sync Button On
        
        GTLRCalendar_Event *addevent = [[GTLRCalendar_Event alloc]init];
        
        // convert string to date format
        
        //    addevent.summary = [[objappdelegate.arrayEvents objectAtIndex:indexpath.row]valueForKey:kName];
        addevent.summary = strName;
        
        //    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        //    [dateFormat setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"];
        //    NSDate *date = [dateFormat dateFromString:[[objappdelegate.arrayEvents objectAtIndex:indexpath.row]valueForKey:kStartDate]];
        //    NSDate *date = [dateFormat dateFromString:strStartDate];
        
        // store start date
        GTLRCalendar_EventDateTime *date_time_start = [[GTLRCalendar_EventDateTime alloc]init];
        //    date_time_start.dateTime = [GTLRDateTime dateTimeWithRFC3339String:[self convertDatetoFormat:@"yyyy-MM-dd'T'HH:mm:ss" withDate:date]];
        date_time_start.dateTime = [GTLRDateTime dateTimeWithRFC3339String:strStartDate];
        addevent.start = date_time_start;
        
        // set after tow days end date
        
        //    NSDateComponents *dayComponent = [[NSDateComponents alloc] init];
        //    dayComponent.day = 2;
        //    NSCalendar *theCalendar = [NSCalendar currentCalendar];
        //    NSDate *dat = [theCalendar dateByAddingComponents:dayComponent toDate:date options:0];
        
        // store end date
        
        GTLRCalendar_EventDateTime *date_time_end = [[GTLRCalendar_EventDateTime alloc]init];
        //    date_time_end.dateTime = [GTLRDateTime dateTimeWithRFC3339String:[self convertDatetoFormat:@"yyyy-MM-dd'T'HH:mm:ss" withDate:dat]];
        date_time_end.dateTime = [GTLRDateTime dateTimeWithRFC3339String:strEndDate];
        addevent.end = date_time_end;
        
        // set update query
        
        GTLRCalendarQuery_EventsUpdate *update = [GTLRCalendarQuery_EventsUpdate queryWithObject:addevent calendarId:strCalenderId eventId:strEventId];
        
        [self.service executeQuery:update completionHandler:^(GTLRServiceTicket * _Nonnull callbackTicket, id  _Nullable object, NSError * _Nullable callbackError) {
            
            if (!callbackError)
            {
                NSLog(@"Update Record success");
                [objappdelegate.arrayEvents removeAllObjects];
                [self fetchEvents];
            }
            else
            {
                NSLog(@"callbackError : %@",[callbackError localizedDescription]);
            }
            
        }];
    }
    else
    {
     //Sync button Off
        [self showAlertWithMessage:@"Oops! Google-sync off"];
    }
}


#pragma mark - Void Methods

-(void)setNotificationWithTile
{
//    UNMutableNotificationContent *localNotification = [UNMutableNotificationContent new];
//    localNotification.title = [NSString localizedUserNotificationStringForKey:@"Time for a run!" arguments:nil];
//    localNotification.body = [NSString localizedUserNotificationStringForKey:@"BTW, running late to happy hour does not count as workout" arguments:nil];
//    localNotification.sound = [UNNotificationSound defaultSound];
//    UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
//
//    localNotification.badge = @([[UIApplication sharedApplication] applicationIconBadgeNumber] +1);
//
//    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"Time for a run!" content:localNotification trigger:trigger];
//
//    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
//    [center addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
//        NSLog(@"Notification created");
//    }];
 
    
    NSArray *arraySchedulNotification = [[UIApplication sharedApplication] scheduledLocalNotifications];
   
    for (int j=0; j<arraySchedulNotification.count; j++)
    {
        [[UIApplication sharedApplication] cancelLocalNotification:[arraySchedulNotification objectAtIndex:j]];
    }
    
    for (int i = 0; i<[objappdelegate arrayEvents].count; i++)
    {
        BOOL isDate = [self checkIsTwoDateWithDateString:[self convertDateToTimeStamp:[[objappdelegate.arrayEvents objectAtIndex:i]valueForKey:kStartDate]]];
        
        if (isDate == true)
        {
            UILocalNotification *localNotification = [[UILocalNotification alloc] init];
            localNotification.soundName = UILocalNotificationDefaultSoundName;
            //        localNotification.fireDate = [self convertStringToDate:@"yyyy-MM-dd'T'HH:mm:ss" withDate:@"2018-01-19T16:16:00+05:30"];
            localNotification.fireDate = [self convertStringToDate:@"yyyy-MM-dd'T'HH:mm:ss" withDate:[[objappdelegate.arrayEvents objectAtIndex:i]valueForKey:kStartDate]];
            localNotification.alertTitle = [[objappdelegate.arrayEvents objectAtIndex:i] valueForKey:kName];
            localNotification.timeZone = [NSTimeZone defaultTimeZone];
            localNotification.alertAction = @"Show";
            localNotification.userInfo = [objappdelegate.arrayEvents objectAtIndex:i];
            //        localNotification.applicationIconBadgeNumber = [[UIApplication sharedApplication] applicationIconBadgeNumber] + 1;
            [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
        }
    }
}

-(NSDate *)convertDateToTimeStamp:(NSString *)strDate
{
    NSDateFormatter *df=[[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssz"];
    [df setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    NSDate *date = [df dateFromString:strDate];
    
//    NSTimeInterval since1970 = [date timeIntervalSince1970]; // January 1st 1970
    
//    return since1970 * 1000;
    return date;
    
}

-(NSString *)convertStringDateWithString:(NSString *)strDate
{
    NSDateFormatter *formatt = [[NSDateFormatter alloc]init];
    [formatt setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssz"];
    NSDate *date = [formatt dateFromString:strDate];
    
//    formatt.timeZone = [NSTimeZone systemTimeZone];
    [formatt setDateFormat:@"yyyy-MM-dd hh:mm a"];
    NSString *strOutPut = [formatt stringFromDate:date];
    
    return strOutPut;
}

-(BOOL)checkIsTwoDateWithDateString:(NSDate *)strDateAnother
{
    if ([[NSDate date] compare:strDateAnother] == NSOrderedSame)
    {
        // are same
        NSLog(@"same");
        return false;
    }
    else if ([[NSDate date] compare:strDateAnother] == NSOrderedAscending)
    {
        NSLog(@"Current Date grater");
        return true;
    }
    else
    {
        NSLog(@"Current Date smaller");
        return false;
    }
}

- (IBAction)ClickControl_SyncData:(UIControl *)sender
{
    if ([self image:self.iamge_sync.image isEqualTo:[UIImage imageNamed:@"uncheck"]])
    {
        self.buttoSync.hidden = false;
        
        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:kSyncGoogle];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [objappdelegate.arrayEvents removeAllObjects];
        self.iamge_sync.image = [UIImage imageNamed:@"checked"];
        [self setSyncDataSetup];
    }
    else
    {
        self.buttoSync.hidden = true;
        [[NSUserDefaults standardUserDefaults]setBool:NO forKey:kSyncGoogle];
        [[NSUserDefaults standardUserDefaults]synchronize];

        self.iamge_sync.image = [UIImage imageNamed:@"uncheck"];
    }
}

- (BOOL)image:(UIImage *)image1 isEqualTo:(UIImage *)image2
{
    NSData *data1 = UIImagePNGRepresentation(image1);
    NSData *data2 = UIImagePNGRepresentation(image2);
    
    return [data1 isEqual:data2];
}

-(void)showAlertWithMessage:(NSString *)strMessage
{
    dispatch_async(dispatch_get_main_queue(), ^{
       
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Google-Calendar" message:strMessage preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil]];
        
        [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alert animated:YES completion:nil];

    });
}

#pragma mark - Extra Methods

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
