//
//  AppDelegate.h
//  Event-Googal-Calender
//
//  Created by NLS17-MAC on 1/13/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <Google/SignIn.h>

#define kName @"name"
#define kStartDate @"startdate"
#define kEndDate @"enddate"
#define kidentifier @"identifier"
#define kSyncGoogle @"googlesync"
#define kLocation @"location"

@interface AppDelegate : UIResponder <UIApplicationDelegate> 

@property (strong, nonatomic) UIWindow *window;

@property (strong ,nonatomic) NSMutableArray *arrayEvents;
@property (strong ,nonatomic) NSMutableArray *array_Events;

@end

