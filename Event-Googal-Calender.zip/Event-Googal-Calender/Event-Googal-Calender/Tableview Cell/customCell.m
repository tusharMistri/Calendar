//
//  customCell.m
//  Event-Googal-Calender
//
//  Created by NLS17-MAC on 1/18/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import "customCell.h"

@implementation customCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
