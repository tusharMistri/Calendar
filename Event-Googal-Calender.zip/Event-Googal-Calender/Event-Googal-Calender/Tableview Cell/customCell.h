//
//  customCell.h
//  Event-Googal-Calender
//
//  Created by NLS17-MAC on 1/18/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customCell : UITableViewCell

@property (strong,nonatomic) IBOutlet UILabel *labelName;
@property (strong,nonatomic) IBOutlet UILabel *labelStartTime;
@property (strong,nonatomic) IBOutlet UILabel *labelendTime;


@end
