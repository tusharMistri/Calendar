//
//  LangaugeManager.swift
//  Localization
//
//  Created by NLS17-MAC on 1/11/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

import UIKit

class LangaugeManager: NSObject {

    let DEFAULTS_KEY_LANGUAGE_CODE = "LanguageCode";

    var arrayLocals =  NSArray()
    
   class func shared() -> LangaugeManager
    {
        var languageManage : LangaugeManager
        languageManage = LangaugeManager.init()
        return languageManage
    }
    
    override init()
    {
        super.init()
        let english = Locals(languageCode: "en", countryCode: "gb", name: "United Kingdom")
        let spnish = Locals(languageCode: "es", countryCode: "es", name: "Spanish")
        let french = Locals(languageCode: "fr", countryCode: "fr", name: "French")
        arrayLocals = [english, spnish, french]
        
    }

    func setLanguageWithLocale(_ locale: Locals)
    {
        UserDefaults.standard.set(locale.strLangaugeCode, forKey: DEFAULTS_KEY_LANGUAGE_CODE)
        UserDefaults.standard.synchronize()
    }
    
    func getTranslationForKey(key : String) -> String
    {
        let languageCode: String? = UserDefaults.standard.string(forKey: DEFAULTS_KEY_LANGUAGE_CODE)?.lowercased()
        // Get the relevant language bundle.
        let bundlePath: String? = Bundle.main.path(forResource: languageCode, ofType: "lproj")
        let languageBundle = Bundle(path: bundlePath ?? "")
        // Get the translated string using the language bundle.
        var translatedString = languageBundle?.localizedString(forKey: key, value: "", table: nil)
        if (translatedString?.count ?? 0) < 1 {
            // There is no localizable strings file for the selected language.
            translatedString = NSLocalizedString(key, tableName: nil, bundle: Bundle.main, value: key, comment: key)
        }
        return translatedString!
    }
    
    
}
