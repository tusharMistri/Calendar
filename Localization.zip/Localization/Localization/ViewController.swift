//
//  ViewController.swift
//  Localization
//
//  Created by NLS17-MAC on 1/11/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var label_name: UILabel!
    @IBOutlet var label_address: UILabel!

    
    
    @IBOutlet var label_time: UILabel!
    
    var counter = Int()
    
    var timer = Timer()

    
    
    var objAppdelegate = AppDelegate()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        counter = 0
        
        objAppdelegate = UIApplication.shared.delegate as! AppDelegate
    }
    
    func changeLanguage() -> Void
    {
        label_name.text = objAppdelegate.CustomLocalisedString(key: "label_name")
        label_address.text = objAppdelegate.CustomLocalisedString(key: "label_address")
    }
    
    @IBAction func buttonEnglish(_ sender: UIButton)
    {
        let langauge = LangaugeManager.shared()
        langauge.setLanguageWithLocale(langauge.arrayLocals[0] as! Locals)
        
        self.changeLanguage()
    }

    @IBAction func buttonSpanish(_ sender: UIButton)
    {
        let langauge = LangaugeManager.shared()
        langauge.setLanguageWithLocale(langauge.arrayLocals[1] as! Locals)

        self.changeLanguage()
    }
    
    @IBAction func buttonFrench(_ sender: UIButton)
    {
        let langauge = LangaugeManager.shared()
        langauge.setLanguageWithLocale(langauge.arrayLocals[2] as! Locals)
        
        self.changeLanguage()
    }
    
    
    @IBAction func buttonTimer(_ sender: UIButton)
    {
        // Scheduling timer to Call the function "updateCounting" with the interval of 1 seconds

        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateCounting), userInfo: nil, repeats: true)
    }
    
    @objc func updateCounting()
    {
        counter = counter + 1
        label_time.text =
            String(counter)
        
        
    }
    
    func timeFormatted(totalSeconds: Int) -> String
    {
        let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        let hours: Int = totalSeconds / 3600
        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

