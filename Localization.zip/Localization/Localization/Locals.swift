//
//  Locals.swift
//  Localization
//
//  Created by NLS17-MAC on 1/11/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

import UIKit

class Locals: NSObject {
    
    var strName : String!
    var strLangaugeCode : String!
    var strCountryCode : String!
    
    init(languageCode: String, countryCode: String, name: String)
    {
        super.init()
        self.strLangaugeCode = languageCode
        self.strCountryCode = countryCode
        self.strName = name
        
    }
}
