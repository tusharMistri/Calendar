//
//  AppDelegate.m
//  Event-Calender
//
//  Created by NLS17-MAC on 1/13/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import "AppDelegate.h"

#import <EventKit/EventKit.h>

@interface AppDelegate ()
{
    EKEventStore *store;
}
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self checkEventStoreAccessForCalendar];
    
    return YES;
}

-(void)checkEventStoreAccessForCalendar
{
    
    //check if we have access to the calendar
    EKAuthorizationStatus status = [EKEventStore authorizationStatusForEntityType:EKEntityTypeEvent];
    
    switch (status)
    {
            // Update our UI if the user has granted access to their Calendar
        case EKAuthorizationStatusAuthorized:
            NSLog(@"EKAuthorizationStatusAuthorized");
            store = [[EKEventStore alloc]init];
            [self fetchCalEvents];
            break;
        case EKAuthorizationStatusNotDetermined:
            NSLog(@"EKAuthorizationStatusNotDetermined");
            [self requestCalendarAccess];
            //respond appropriate here, example.
            //request permission to access the calendar
            break;
            //we don't have permission
        case EKAuthorizationStatusDenied:
            NSLog(@"EKAuthorizationStatusDenied");
        case EKAuthorizationStatusRestricted:
        {
            NSLog(@"EKAuthorizationStatusRestricted");
            //we don't have permission to access the calendar
            //we could display an alert to the user saying we don't have access
        }
            break;
        default:
            break;
    }
}

-(void)requestCalendarAccess
{
    store = [[EKEventStore alloc]init];
    //assuming store is an EKEventStore object that has already been initialized somewhere else
    //and we can access it from here.
    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             NSLog(@"Permission is Granted ...");
             
             [self fetchCalEvents];
         }
         else
         {
             NSLog(@"Permission not Granted ...");
         }
     }];
}

-(void) fetchCalEvents
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    //create a day component for 10 day ago.
    //we'll search for events within a timespan starting 10 days ago.
    NSDateComponents *daysAgoComponents = [[NSDateComponents alloc] init];
    daysAgoComponents.day = -10;
    //create a day component for 10 days from now.
    //we'll search for events within a timespan 10 days into the future.
    NSDateComponents *daysFromNowComponents = [[NSDateComponents alloc] init];
    daysFromNowComponents.day = 10;
    
    //now need to use the components to build actual dates.
    //the date 10 days ago
    NSDate *daysAgo = [calendar dateByAddingComponents:daysAgoComponents toDate:[NSDate date] options:0];
    //the date 10 days into the future
    NSDate *daysFromNow = [calendar dateByAddingComponents:daysFromNowComponents toDate:[NSDate date] options:0];
    
    // We will only search the default calendar for our events
    //grab the default calendar for calendar events
    EKCalendar *defaultCalendar = store.defaultCalendarForNewEvents;
    //array of calendars we will search
    NSArray *calendarArray = [NSArray arrayWithObject:defaultCalendar];
    
    //next we need to create a predicate object to cover the date range we'd like to search.
    //which is for events that fall within the timespan of 10 days ago to 10 days into the future
    //if we want to search all the calends instead of just the default, pass nil for the "calendars" param
    NSPredicate *predicate = [store predicateForEventsWithStartDate:daysAgo endDate:daysFromNow calendars:calendarArray];
    
    //search for all events withing the date range defined by the predicate.
    NSArray *events = [store eventsMatchingPredicate:predicate];
    
    for(EKEvent *e in events){
        
        //inherited from EKCalendarItem
        //this can be used as the local identifier for the events
        //because its value is set when the event is created on the local device
        NSLog(@"%@",e.calendarItemIdentifier);
        //this ID is used to identify the same event across multiple devices
        //because .calendarItemIdentifier will be different on each.
        NSLog(@"%@",e.calendarItemExternalIdentifier);
        
        //can use this id with EKEventStore method :eventWithIdentifier: to find event
        //if the event is move to another calendar this ID will likely change.
        NSLog(@"eventIdentifier: %@",e.eventIdentifier);//Event ID: string
        NSLog(@"start date: %@",e.startDate);//date in default timezone: NSDate
        NSLog(@"end date: %@",e.endDate);//date in default timezone: NSDate
        NSLog(@"all day: %d",e.allDay);//all day event? : Bool
        NSLog(@"organizer: %@",e.organizer); //: EKParticipant or nil
        //values:
        //EKEventStatusNone
        //EKEventStatusConfirmed
        //EKEventStatusTentative
        //EKEventStatusCanceled (this is the important one)
        NSLog(@"status: %i",e.status); //:  EKEventStatus enum
        
        //these are inherited from the parent class of EKEvent, EKCalendarItem
        NSLog(@"title: %@",e.title);//Title: string
        NSLog(@"location: %@",e.location);//Title: string
        NSLog(@"creation date: %@",e.creationDate);//: NSDate
        NSLog(@"modified date: %@",e.lastModifiedDate);//: NSDate
        NSLog(@"timezone: %@",e.timeZone);//: NSTimeZone
        NSLog(@"url: %@",e.URL);//event url: NSURL
        
    }
}




- (void)applicationWillResignActive:(UIApplication *)application {
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
}


- (void)applicationWillTerminate:(UIApplication *)application {
}


@end
