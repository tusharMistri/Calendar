//
//  ViewController.m
//  Event-Calender
//
//  Created by NLS17-MAC on 1/13/18.
//  Copyright © 2018 NLS17-MAC. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()
{
    NSString *savedEventId;
    AppDelegate *objappdelegate;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    objappdelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
}

-(void)AddEvent
{
    EKEventStore *store = [[EKEventStore alloc] init];
    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
        if (!granted) return;
        EKEvent *event = [EKEvent eventWithEventStore:store];
        event.title = @"Event Name Test1";
        event.startDate = [NSDate date]; // today
        event.endDate = [event.startDate dateByAddingTimeInterval:60*60];  // Duration 1 hr
        [event setCalendar:[store defaultCalendarForNewEvents]];
        NSError *err = nil;
        [store saveEvent:event span:EKSpanThisEvent commit:YES error:&err];
        savedEventId = event.eventIdentifier;  // Store this so you can access this event later
        
        if (!err)
        {
            [objappdelegate fetchCalEvents];
        }
        
    }];
}

-(void)EditEvent
{
    EKEventStore *store = [[EKEventStore alloc] init];
    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
        if (!granted) return;
        EKEvent *event = [store eventWithIdentifier:@"B0C95D03-E23B-4540-BB36-BF1090EC9560:54E664FD-715B-4114-BDBC-96FC765FAA7F"];
        // Uncomment below if you want to create a new event if savedEventId no longer exists
        // if (event == nil)
        //   event = [EKEvent eventWithEventStore:store];
        if (event) {
            NSError *err = nil;
            event.title = @"New event title";
            [store saveEvent:event span:EKSpanThisEvent commit:YES error:&err];
            
            if (!err)
            {
                [objappdelegate fetchCalEvents];
            }
        }
    }];
}

-(void)DeleteEvent
{
    EKEventStore *store = [[EKEventStore alloc] init];
    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
        if (!granted) return;
        EKEvent* eventToRemove = [store eventWithIdentifier:savedEventId];
        if (eventToRemove) {
            NSError* err = nil;
            [store removeEvent:eventToRemove span:EKSpanThisEvent commit:YES error:&err];
        }
    }];
}

- (IBAction)buttonClickAddEvent:(UIButton *)sender
{
    [self AddEvent];
}

- (IBAction)buttonClickDeleteEvent:(UIButton *)sender
{
    
}

- (IBAction)buttonClickUpdateEvent:(UIButton *)sender
{
    [self EditEvent];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
